export function AnnouncementBar() {
  return (
    <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white py-2 overflow-hidden">
      <div className="animate-marquee whitespace-nowrap">
        <span className="text-sm font-medium px-4">
          ✨ this website build by harmain ali aka harmain.dev ✨
        </span>
        <span className="text-sm font-medium px-4">
          ✨ this website build by harmain ali aka harmain.dev ✨
        </span>
        <span className="text-sm font-medium px-4">
          ✨ this website build by harmain ali aka harmain.dev ✨
        </span>
        <span className="text-sm font-medium px-4">
          ✨ this website build by harmain ali aka harmain.dev ✨
        </span>
      </div>
    </div>
  );
}
